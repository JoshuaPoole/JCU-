public class TrumpCard extends Card{
    String title;
    String subtitle;

    TrumpCard(String in_fileName, String in_title, String in_subtitle){
        fileName = in_fileName;
        title = in_title;
        subtitle = in_subtitle;
    }

    public String getTitle(){
        return title;
    }
    public String getSubtitle(){
        return subtitle;
    }
    public String toString(){
        String trumpString = "<" + title + "," + subtitle + ">";
        return trumpString;
    }
}
