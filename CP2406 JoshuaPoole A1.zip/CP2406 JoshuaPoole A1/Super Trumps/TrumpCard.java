public class TrumpCard extends Card{
    String title;
    String subtitle;

    TrumpCard(String in_title, String in_subtitle){
        title = in_title;
        subtitle = in_subtitle;
    }

    String getName(){
        return name;
    }
}
