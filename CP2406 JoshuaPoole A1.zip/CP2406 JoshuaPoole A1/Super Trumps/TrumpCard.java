public class TrumpCard extends Card{

    TrumpCard(String in_name){
        name = in_name;
    }

    String getName(){
        return name;
    }
}
