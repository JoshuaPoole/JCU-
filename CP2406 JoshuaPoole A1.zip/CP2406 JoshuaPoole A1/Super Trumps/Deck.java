import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.NSString;
import com.dd.plist.PropertyListParser;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

/**
 * Created by jc313836 on 19/09/16.
 */
public class Deck {
    private ArrayList<Card> deck;
    private Card card;
    private int cardsOut;

    public Deck(){
        deck = new ArrayList<Card>();
        try {
            Scanner input = new Scanner(System.in);
            File file = new File("MstCards_151021.plist");
            NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(file);

            NSArray key = (NSArray)rootDict.objectForKey("cards");

            for(int i = 0; i < key.getArray().length; i++){
                NSDictionary card = (NSDictionary)key.objectAtIndex(i);

                if(card.size() == 4){
                    NSString title = (NSString)card.objectForKey("title");
                    NSString subtitle = (NSString)card.objectForKey("subtitle");
                    deck.add(new TrumpCard(title.getContent(), subtitle.getContent()));
                }
                else if(card.size() == 12){
                    String occurrence = "";
                    NSString title = (NSString)card.objectForKey("title");
                    NSString chemistry = (NSString)card.objectForKey("chemistry");
                    NSString classification = (NSString)card.objectForKey("classification");
                    NSString crystalSystem = (NSString)card.objectForKey("crystal_system");

                    NSArray occurrenceArray = (NSArray)card.objectForKey("occurrence");
                    for( int j =0; j< occurrenceArray.getArray().length; j++){
                        NSString occurrenceTemp = (NSString)occurrenceArray.objectAtIndex(j);
                        occurrence += occurrenceTemp.getContent() + " ";
                    }
                    NSString hardness = (NSString)card.objectForKey("hardness");
                    NSString specificGravity = (NSString)card.objectForKey("specific_gravity");
                    NSString cleavage = (NSString)card.objectForKey("cleavage");
                    NSString crustalAbundance = (NSString)card.objectForKey("crustal_abundance");
                    NSString economicValue = (NSString)card.objectForKey("economic_value");
                    deck.add(new PlayCard(title.getContent(), chemistry.getContent(), classification.getContent(), crystalSystem.getContent(), occurrence,  "Hardness",hardness.getContent(), "SpecificGravity", specificGravity.getContent(),  "Cleavage",cleavage.getContent(),   "CrustalAbundance", crustalAbundance.getContent(),  "EconomicValue", economicValue.getContent() ));

                }
            }
            //input.nextLine();

        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }
    public boolean isEmpty(){
        return deck.isEmpty();
    }
    public Card assign(){
        if (!isEmpty()){
            return deck.get(1);
        }else{
            return null;
        }
    }

    public int getSize (){

        return deck.size();
    }
    Card getCard(int i){

        return deck.get(i);
    }
    String getLast(){

        return deck.get(deck.size()-1).toString();
    }
    public void shuffle(){
        for (int i = deck.size()-1; i >0; i--){
            int rand = (int)(Math.random()* (i+1));
            Card currentCard = deck.get(i);
            deck.remove(i);
            Card nextCard = deck.get(rand);
            deck.remove(rand);
            deck.add(currentCard);
            deck.add(nextCard);

        }
        cardsOut = 0;
    }
    public int cardsRemain(){

        return deck.size() - cardsOut;
    }
    public Card dealCard(){
        if (cardsOut == deck.size())
            throw new IllegalStateException("No cards are left in the deck.");
        cardsOut ++;
        return deck.get(cardsOut - 1);
    }
    public String toString(){
        String deckString = "";
        for (int x =0; x < deck.size()-1; x++){
            deckString += deck.get(x).toString() + "\n";
        }
        return deckString;

    }

}
