import java.util.ArrayList;

/**
 * Created by jc313836 on 19/09/16.
 */
public class Deck {
    private ArrayList<Card> cards;

    Deck(){
        cards = new ArrayList<Card>();
    }

    void addCard(Card in_card){
        cards.add(in_card);
    }

    String getLast(){
        return cards.get(cards.size()-1).toString();
    }
}
