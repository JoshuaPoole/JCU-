import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Josh on 10/24/2016.
 */
public class SuperTrumpsGUI {
    private JPanel MenuPanel;
    private JButton playButton;
    private JButton instructionsButton;
    private JButton quitButton;
    private JPanel titlePanel;
    private JPanel buttonPanel;
    private JLabel Title;

    public SuperTrumpsGUI() {
        JFrame frame1 = new JFrame("MineralSuperTrumps");
        frame1.setContentPane(this.MenuPanel);
        frame1.setSize(700, 600);
        frame1.setVisible(true);
        

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Game game = new Game();
                game.start();
            }
        });instructionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Each Player is dealt 8 cards from the deck. Players have 3 options:\n1. look at your cards (This displays the attributes of each of your cards).\n2. Play card (Select one of your cards and then select one of its categories; for example, Hardness: 2.5 Specific Gravity: 3. \nThe first time a card is played, the category and value are set as the trump value, meaning that the next player must play a\n card with a higher value in the same category as the trump value. If they cannot then they must choose to pass.)\n 3. Pass (When a player passes the player will skip each round until either all except for one player has passed or until the\n trump value is changed. The game will continue until all but one player has no cards. The first player to lose all their cards\n is the winner.");

            }
        });
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);;
            }
        });

    }
}
