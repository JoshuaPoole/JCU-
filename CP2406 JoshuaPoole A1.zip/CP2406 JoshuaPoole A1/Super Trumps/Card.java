/**
 * Created by jc313836 on 20/09/16.
 */
public class Card {
    String name;

    @Override
    public String toString(){
        return name;
    }
}


