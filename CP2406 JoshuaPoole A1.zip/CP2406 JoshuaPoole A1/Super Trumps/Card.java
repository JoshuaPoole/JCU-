/**
 * Created by jc313836 on 20/09/16.
 */
public class Card {
    String name;
    String chemistry;
    String classification;
    String crystalSystem;
    String occurrenceString;
    String hardness;
    String specificGravity;
    String cleavage;
    String crustalAbundance;
    String economicValue;
    String title;
    String subtitle;
    String hardnessStr;
    String specificGravityStr;
    String cleavageStr;
    String crustalAbundanceStr;
    String economicValueStr;


    Card(){

    }

    public String getTitle(){
        return title;
    }
    public String getSubtitle(){
        return subtitle;
    }
    public String getName(){
        return name;
    }
 // The commented out code is code that is not used.
//    public String getChemistry(){
//        return chemistry;
//    }
//    public String getClassification(){
//        return classification;
//    }
//    public String getCrystalSystem(){
//        return crystalSystem;
//    }
//    public String getOccurrenceString(){
//        return occurrenceString;
//    }
    public String getHardness(){
        return hardness;
    }
    public String getSpecificGravity(){
        return specificGravity;
    }
//    public String getCleavage(){
//        return cleavage;
//    }
//    public String getCrustalAbundance(){
//        return crustalAbundance;
//    }
//    public String getEconomicValue(){
//        return economicValue;
//    }
//    public String getCleavageStr() {
//        return cleavageStr;
//    }

//    public String getCrustalAbundanceStr() {
//        return crustalAbundanceStr;
//    }

    public String getSpecificGravityStr() {
        return specificGravityStr;
    }

//    public String getEconomicValueStr() {
//        return economicValueStr;
//    }

    public String getHardnessStr() {
        return hardnessStr;
    }

}


