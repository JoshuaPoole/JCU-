import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Josh on 10/24/2016.
 */
public class Form2 {
    private JLabel Text;
     JRadioButton a3RadioButton;
     JRadioButton a4RadioButton;
     JRadioButton a5RadioButton;
    private JPanel playerAmount;
     JButton okayButton;
    private JPanel optionPanel;

    private JFrame frame2;

    public void setVisible(boolean visible){
        frame2.setVisible(visible);
    }


    public Form2() {
        frame2 = new JFrame("Mineral SuperTrumps");
        frame2.setContentPane(this.optionPanel);
        frame2.setSize(700, 600);
    }
}
