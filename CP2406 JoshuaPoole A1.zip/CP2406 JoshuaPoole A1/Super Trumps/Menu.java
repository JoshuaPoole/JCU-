import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
/**
 * Created by jc313836 on 13/09/16.
 * GitHub link: https://github.com/JoshuaPoole/Programing2/tree/Assessment-1
 */
public class Menu extends JFrame{
    static Game _game;
    static ArrayList<Player> players;
    static Deck deck;



    public static void main(String[] args){

        JFrame f=new JFrame("Mineral Super-Trumps");
        //f.getContentPane().setBackground( Color.gray );

        JLabel title  = new JLabel("MINERAL SUPER-TRUMPS");
        title.setBounds(110, 100, 600, 60);
        title.setFont(new Font("Impact", Font.BOLD, 45));
        f.add(title);

        JButton playButton=new JButton("Play");
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                _game = new Game();
                _game.start();
            }
        });
        playButton.setBounds(245,300,200, 60);
        f.add(playButton);

        JButton instructionButton=new JButton("Instructions");
        instructionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Each Player is dealt 8 cards from the deck. Players have 3 options:\n1. look at your cards (This displays the attributes of each of your cards).\n2. Play card (Select one of your cards and then select one of its categories; for example, Hardness: 2.5 Specific Gravity: 3. \nThe first time a card is played, the category and value are set as the trump value, meaning that the next player must play a\n card with a higher value in the same category as the trump value. If they cannot then they must choose to pass.)\n 3. Pass (When a player passes the player will skip each round until either all except for one player has passed or until the\n trump value is changed. The game will continue until all but one player has no cards. The first player to lose all their cards\n is the winner.");
            }
        });
        instructionButton.setBounds(245,370,200, 60);
        f.add(instructionButton);

        JButton quitButton=new JButton("Quit");
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);;
            }
        });
        quitButton.setBounds(245,440,200, 60);
        f.add(quitButton);

        f.setSize(700,600);
        f.setLayout(null);
        f.setVisible(true);

//        Scanner input = new Scanner(System.in);
//        System.out.println("(P)lay, (I)nstructions, (Q)uit");
//        String userInput = input.nextLine();
//        boolean running = false;
//        while (!(running)){
//            if (!(userInput .equalsIgnoreCase("p") || userInput .equalsIgnoreCase("i") || userInput .equalsIgnoreCase("q"))) {
//                System.out.println("Error invalid input.");
//                System.out.println("(P)lay, (I)nstructions, (Q)uit");
//                userInput = input.nextLine();
//            }else if ((userInput .equalsIgnoreCase("i"))) {
//                running = false;
//                System.out.println("Each Player is dealt 8 cards from the deck. Players have 3 options:\n 1. look at your cards (This displays the attributes of each of your cards).\n 2. Play card (You must select one of you cards and then select one of its\n  categories; for example, Hardness: 2.5 Specific Gravity: 3. The first time\n a card is played, the category and value are set as the trump value, meaning\n that the next player must play a card with a higher value in the same category\n  as the trump value, if they cannot then they must choose to pass.)\n 3. Pass (When a player passes the player will skip each round until either all\n  except for one player has passed or until the trump value is changed. The game\n  will continue until all but one player has no cards. The first player to lose\n  all their cards is the winner.");
//                System.out.print("(P)lay, (I)nstructions, (Q)uit");
//                userInput = input.nextLine();
//            }else if ((userInput .equalsIgnoreCase("Q"))) {
//                System.exit(0);
//            }else if ((userInput .equalsIgnoreCase("p"))){
//                _game = new Game();
//                System.out.println("Game over.");
//                System.out.println("Restart? Y/N");
//                userInput = input.nextLine();
//                if (userInput.equalsIgnoreCase("Y") ){
//                    running = false;
//                    System.out.println("(P)lay, (I)nstructions, (Q)uit");
//                    userInput = input.nextLine();
//
//                }else if (userInput.equalsIgnoreCase("N")){
//                    running = true;
//                    System.exit(0);
//                }else{
//                    System.out.print("invalid input.");
//                    System.out.print("(P)lay, (I)nstructions, (Q)uit");
//                    userInput = input.nextLine();
//                }
//
//            }

        //createPlayers(playerNumber);
        //cardReader();
    }}
//}

