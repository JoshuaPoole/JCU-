import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import com.dd.plist.*;
import java.text.ParseException;



/**
 * Created by jc313836 on 13/09/16.
 */
public class Menu {
    static Game _game;
    static ArrayList<Player> players;
    static Deck deck;

    public static void main(String[] args)
    {
        //_game = new Game();
        Scanner input = new Scanner(System.in);
        System.out.print("(P)lay, (I)nstructions, (Q)uit");
        String userInput = input.nextLine();
        boolean running = false;
        while (!(running)){
            if (!(userInput .equalsIgnoreCase("p") || userInput .equalsIgnoreCase("i") || userInput .equalsIgnoreCase("q"))) {
                System.out.print("invalid input.");
                System.out.print("(P)lay, (I)nstructions, (Q)uit");
                userInput = input.nextLine();
            }else if ((userInput .equalsIgnoreCase("i"))) {
                running = false;
                System.out.println("enter instructions here");
                System.out.print("(P)lay, (I)nstructions, (Q)uit");
                userInput = input.nextLine();
            }else if ((userInput .equalsIgnoreCase("Q"))) {
                System.exit(0);
            }else if ((userInput .equalsIgnoreCase("p"))){
                _game = new Game();

                running = true;


            }

        //createPlayers(playerNumber);
        //cardReader();
    }}
}

