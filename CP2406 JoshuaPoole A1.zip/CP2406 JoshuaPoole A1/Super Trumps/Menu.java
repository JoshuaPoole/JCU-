import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by jc313836 on 13/09/16.
 */
public class Menu {
    static ArrayList<Player> players;

    public static void main(String[] args)
    {
        int playerNumber;
        Scanner input = new Scanner(System.in);
        System.out.print("How many players?");
        playerNumber = input.nextInt();
        if((playerNumber != 3 && playerNumber!= 4 && playerNumber !=5)){
            System.out.println("Error invalid input");
            System.out.print("How many players?");
        }
        createPlayers(playerNumber);
    }

    public static void createPlayers(int number){
        players = new ArrayList<Player>(number);
        //need to give player cards    }
}}

