import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
/**
 * Created by jc313836 on 13/09/16.
 * GitHub link: https://github.com/JoshuaPoole/Programing2/tree/Assessment-1
 */
public class Menu extends JFrame{
    static Game _game;
    static ArrayList<Player> players;
    static Deck deck;

    public static void main(String[] args){
    new SuperTrumpsGUI();

//        Scanner input = new Scanner(System.in);
//        System.out.println("(P)lay, (I)nstructions, (Q)uit");
//        String userInput = input.nextLine();
//        boolean running = false;
//        while (!(running)){
//            if (!(userInput .equalsIgnoreCase("p") || userInput .equalsIgnoreCase("i") || userInput .equalsIgnoreCase("q"))) {
//                System.out.println("Error invalid input.");
//                System.out.println("(P)lay, (I)nstructions, (Q)uit");
//                userInput = input.nextLine();
//            }else if ((userInput .equalsIgnoreCase("i"))) {
//                running = false;
//                System.out.println("Each Player is dealt 8 cards from the deck. Players have 3 options:\n 1. look at your cards (This displays the attributes of each of your cards).\n 2. Play card (You must select one of you cards and then select one of its\n  categories; for example, Hardness: 2.5 Specific Gravity: 3. The first time\n a card is played, the category and value are set as the trump value, meaning\n that the next player must play a card with a higher value in the same category\n  as the trump value, if they cannot then they must choose to pass.)\n 3. Pass (When a player passes the player will skip each round until either all\n  except for one player has passed or until the trump value is changed. The game\n  will continue until all but one player has no cards. The first player to lose\n  all their cards is the winner.");
//                System.out.print("(P)lay, (I)nstructions, (Q)uit");
//                userInput = input.nextLine();
//            }else if ((userInput .equalsIgnoreCase("Q"))) {
//                System.exit(0);
//            }else if ((userInput .equalsIgnoreCase("p"))){
//                _game = new Game();
//                System.out.println("Game over.");
//                System.out.println("Restart? Y/N");
//                userInput = input.nextLine();
//                if (userInput.equalsIgnoreCase("Y") ){
//                    running = false;
//                    System.out.println("(P)lay, (I)nstructions, (Q)uit");
//                    userInput = input.nextLine();
//
//                }else if (userInput.equalsIgnoreCase("N")){
//                    running = true;
//                    System.exit(0);
//                }else{
//                    System.out.print("invalid input.");
//                    System.out.print("(P)lay, (I)nstructions, (Q)uit");
//                    userInput = input.nextLine();
//                }
//
//            }

        //createPlayers(playerNumber);
        //cardReader();
    }}
//}

