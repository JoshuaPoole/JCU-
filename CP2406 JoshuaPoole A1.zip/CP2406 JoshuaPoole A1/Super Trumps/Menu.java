import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import com.dd.plist.*;
import java.text.ParseException;



/**
 * Created by jc313836 on 13/09/16.
 */
public class Menu {
    static ArrayList<Player> players;
    static Deck deck;

    public static void main(String[] args)
    {
        deck = new Deck();
        Scanner input = new Scanner(System.in);
        System.out.print("(P)lay, (I)nstructions, (Q)uit");
        String userInput = input.nextLine();
        boolean running = false;
        while (!(running)){
            if (!(userInput .equalsIgnoreCase("p") || userInput .equalsIgnoreCase("i") || userInput .equalsIgnoreCase("q"))) {
                System.out.print("invalid input.");
                System.out.print("(P)lay, (I)nstructions, (Q)uit");
                userInput = input.nextLine();
            }else if ((userInput .equalsIgnoreCase("i"))) {
                running = false;
                System.out.print("enter instructions here");
                System.out.print("(P)lay, (I)nstructions, (Q)uit");
                userInput = input.nextLine();
            }else if ((userInput .equalsIgnoreCase("Q"))) {
                System.exit(0);
            }else if ((userInput .equalsIgnoreCase("p"))){
                int playerNumber;
                System.out.print("Enter the amount of players(must be between 3 and 5)");
                playerNumber = input.nextInt();
                while((playerNumber != 3 && playerNumber!= 4 && playerNumber !=5)){
                    System.out.println("Error invalid input");
                    System.out.print("How many players?");
                    playerNumber = input.nextInt();
                }
                running = true;
        createPlayers(playerNumber);
        cardReader();
    }}}

    public static void cardReader(){
        try {
            Scanner input = new Scanner(System.in);
            File file = new File("MstCards_151021.plist");
            NSDictionary rootDict = (NSDictionary)PropertyListParser.parse(file);

            NSArray key = (NSArray)rootDict.objectForKey("cards");
            for(int i = 0; i < key.getArray().length; i++){
                NSDictionary card = (NSDictionary)key.objectAtIndex(i);

                if(card.size() == 4){
                    NSString title = (NSString)card.objectForKey("title");
                    deck.addCard(new TrumpCard(title.getContent()));
                }
                else if(card.size() == 12){
                    NSString title = (NSString)card.objectForKey("title");
                    NSString chemistry = (NSString)card.objectForKey("chemistry");
                    NSString classification = (NSString)card.objectForKey("classification");
                    NSString crystalSystem = (NSString)card.objectForKey("crystal_system");
                    NSString occurrence = (NSString)card.objectForKey("occurrence"); // < needs fixing, error caused because it is an array.
                    NSString hardness = (NSString)card.objectForKey("hardness");
                    NSString specificGravity = (NSString)card.objectForKey("specific_gravity");
                    NSString cleavage = (NSString)card.objectForKey("cleavage");
                    NSString crustalAbundance = (NSString)card.objectForKey("crustal_abundance");
                    NSString economicValue = (NSString)card.objectForKey("economic_value");
                    deck.addCard(new PlayCard(title.getContent(), chemistry.getContent(), classification.getContent(), crystalSystem.getContent(), occurrence.getContent(), hardness.getContent(), specificGravity.getContent(), cleavage.getContent(), crustalAbundance.getContent(), economicValue.getContent()  ));
                }

                System.out.println(deck.getLast());
            }

            input.nextLine();

        } catch(Exception ex) {
                ex.printStackTrace();
        }
    }

    public static void createPlayers(int number){
        players = new ArrayList<Player>(number);

}}

