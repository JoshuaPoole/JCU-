import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

/**
 * Created by jc313836 on 13/09/16.
 * GitHub link: https://github.com/JoshuaPoole/Programing2/tree/Assessment-2
 */

/* this is the controller object for the MVC*/
public class Menu extends JFrame {
    static Game _game;
    static Player player;
    static ArrayList<Player> players;
    static Deck deck;
    static Form1 form1; /*This is the gui form for the menu*/
    static Form2 form2; /*This is the gui form for selecting the number of players and entering the player id*/
    static Form3 form3; /*This is the gui form for the game*/
    //


    public static void main(String[] args) {
        _game = new Game();

        form1 = new Form1();
        form2 = new Form2();
        form3 = new Form3();

        form1.playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                form1.setVisible(false);
                form2.setVisible(true); /*When the user clicks the play button, the menu gui is made invisible and the gui for getting the number of players and player id is made visible*/
            }
        });
        form1.instructionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Each Player is dealt 8 cards from the deck. Players have 3 options:\n1. look at your cards (This displays the attributes of each of your cards).\n2. Play card (Select one of your cards and then select one of its categories; for example, Hardness: 2.5 Specific Gravity: 3. \nThe first time a card is played, the category and value are set as the trump value, meaning that the next player must play a\n card with a higher value in the same category as the trump value. If they cannot then they must choose to pass.)\n 3. Pass (When a player passes the player will skip each round until either all except for one player has passed or until the\n trump value is changed. The game will continue until all but one player has no cards. The first player to lose all their cards\n is the winner.");
            }
        });
        form1.quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            } /*When the user presses the quit button the program closes*/
        });

        form2.a3RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                _game.playerNumber = 3;
            }
        });
        form2.a4RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                _game.playerNumber = 4;
            }
        });
        form2.a5RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                _game.playerNumber = 5;
            }
        });
        form2.okayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Boolean correct = false; /*While the users input isn't correct, the program will error check and ask them for input */
                while(!correct){
                    try{
                        _game.playerID = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter your player id; 1 2 3 4 or 5 (Must be within the amount of players)"));
                        correct = true;
                    }catch(NumberFormatException r){
                        JOptionPane.showMessageDialog(null, "Error Invalid Input; Please enter a number within the amount of players");
                        continue;
                    }
                    if((_game.playerID > _game.playerNumber) || _game.playerID < 1){
                        JOptionPane.showMessageDialog(null, "Error Invalid Input; Please enter a number within the amount of players");
                        _game.playerID = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter your player id; 1 2 3 4 or 5 (Must be within the amount of players)"));
                    }
                }
                form2.setVisible(false);
                form3.setVisible(true);
            }
        });
        form3.playCards.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                form3.gameMessage.setText(" Choose a card to play");
            }
        });
        form3.pass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                form3.gameMessage.setText("Player " + _game.playerID + " passes");
            }
        });

        String cardList = "\n Your CardList \n";
        ArrayList<Card> playcards = player.hand.getPlaycards();
        for (int i = 1; i< playcards.size(); i++){
            cardList += i + ", " + playcards.get(i-1) + "\n";
            JButton cardButton=new JButton(String.valueOf(i));
            form3.add(cardButton);
        }


        form1.setVisible(true); /*On startup the menu form is made visible */
    }
}


