import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

/**
 * Created by Josh on 10/24/2016.
 */
public class Form3 {
    public JButton playCards;
    public JButton pass;
    private JPanel gameOptions;
     JPanel gameTable;
    private JPanel GamePanel;
    public JLabel gameMessage;
    private JFrame frame3;

    public void setVisible(boolean visible){
        frame3.setVisible(visible);
    }

    public Form3(){
        frame3 = new JFrame("Mineral SuperTrumps");
        frame3.setContentPane(this.GamePanel);
        frame3.setSize(800, 700);
        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
//    public void add(JButton cardButton) {
//        gameTable.add(cardButton);
//    }
}
