import java.util.*;

/**
 * Created by Josh on 9/27/2016.
 */
public class Game {

    ArrayList<Player> players;
    ArrayList<Player> winners;
    ArrayList<Player> passPlayers;
    ArrayList<Player> tempPlayers;
    private Deck deck;
    private int option;
    private int playerID;
    private boolean start;
    private Card playCard;
    Map<String, Double> trumpValue;
    int trumpCount = 0;
    public Scanner input = new Scanner(System.in);
    boolean starting = true;
    int catagoryNumber;
    int cardNumber;

    public Game() {
        players = new ArrayList<Player>();
        passPlayers = new ArrayList<Player>();
        winners = new ArrayList<Player>();
        tempPlayers = new ArrayList<Player>();
        trumpValue = new HashMap<String, Double>();
        start();
    }

    public void start() {

        int playerNumber;
        System.out.println("Enter the amount of players(must be between 3 and 5)");
        playerNumber = input.nextInt();
        while ((playerNumber != 3 && playerNumber != 4 && playerNumber !=5)) {
            System.out.println("Error invalid input");
            System.out.println("Enter the amount of players(must be between 3 and 5)");
            playerNumber = input.nextInt();
        }
        System.out.println("Initializing players...");
        deck = new Deck(); /*Imports cards from MstCards_151021.plist*/
        deck.shuffle(); /*Shuffles cards in deck*/
        System.out.println("Shuffling and dealing cards...");

        for (int i = 1; i <= playerNumber; i++) {/*Creates player arrays and puts cards in them*/
            Player player = new Player(deck);
            players.add(player);
            tempPlayers.add(player);
        }
        System.out.println("Choose your player id;(1), (2), (3), (4), or (5):");
        playerID = input.nextInt();
        while ((playerID > playerNumber) && playerID != 1 && playerID != 2 && playerID != 3 && playerID != 4 && playerID != 5) {
            System.out.println("Error invalid input");
            System.out.println("Choose your player id:");
            playerID = input.nextInt();
        }

        tempPlayers.remove(playerID-1);


        while (starting){
            System.out.println("Game options:(1) Look your cards; (2) Play cards; (3) Pass");
            option = input.nextInt();
            while (option != 1 && option != 2 && option != 3) {
                System.out.println("Error invalid input, please input '1', '2' or '3'");
                System.out.println("Game options:(1) Look your cards; (2) Play cards; (3) Pass");
                option = input.nextInt();
            }
            if (option == 1) {
                starting = true;
                System.out.println(players.get(playerID - 1).toString() + ":" + players.get(playerID-1).showCardList(option)); //Shows a list of each of the player's cards

            }
            else if (option == 2) {
                starting = true;
                int cardSize = 0;
                int winID = 0;
                for (Player player: players) {
                    cardSize = player.handCardNumber();
                    winID = players.indexOf(player);
                }
                if (cardSize == 0 && winID == 0) { /*If the player has no cards left and there is no current winner then the player is declared the winner*/
                    System.out.println("The Winner is Player" + winID);
                    starting = false;
                }else{
                         trumpValue.clear();
                         play();
                         trumpCount++;

//                    }
                    game();

                    starting = true;
                    trumpCount =0;

                }
            }
            else if (option == 3) {
                passPlayers.clear();
                pass(playerID-1);
                if (!deck.isEmpty()) {
                    players.get(playerID - 1).pickCard(deck.assign());
                }
                if (passPlayers.size() != players.size() - 1){ /*if the amount of players that have passed is equal to the amount of players - 1 then all players that have passed are allowed to play again*/
                    passPlayers.clear();
                    playCard = tempPlayers.get(tempPlayers.size()-1).outPlayCard(tempPlayers.get(tempPlayers.size()-1).handCardNumber()); /*the tempPlayers play their cards.*/
                    if (playCard.getHardness().contains("-")) { /* In the Plist file some cards have values like 6.5 - 7.2 in their Hardness and SpecificGravityCategory, this code checks if the card selected is like this and puts the category of the card and the highest value of the two in the trumpValue*/
                        System.out.println("Player " + tempPlayers.get(tempPlayers.size()-1) + " played " + playCard.getHardnessStr() + ":" + playCard.getHardness().split("-")[1]);
                        trumpValue.put(playCard.getHardnessStr(), Double.parseDouble(playCard.getHardness().split("-")[1]));
                    } else {
                        System.out.println("Player " + tempPlayers.get(tempPlayers.size()-1) + " played " + playCard.getHardnessStr() + ":" + playCard.getHardness());
                        trumpValue.put(playCard.getHardnessStr(), Double.parseDouble(playCard.getHardness()));
                    }
                    for (int i = 0; i < tempPlayers.size()-2; i++){
                        int count = 0;
                        for (int j = 1; j <= tempPlayers.get(i).handCardNumber(); j++){
                            if ((tempPlayers.get(i).outPlayCard(j).getHardnessStr()) == "Hardness" ){
                                if (tempPlayers.get(i).outPlayCard(j).getHardness().contains("-") && (Double.parseDouble(playCard.getHardness().split("-")[1]) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", "")))) {
                                    System.out.println("Player " + (playerID - 1) + " plays " + playCard.getHardnessStr() + ": " + playCard.getHardness().split("-")[1]);
                                    tempPlayers.get(i).playCard(tempPlayers.get(i).outPlayCard(j));
                                    trumpValue.replace(tempPlayers.get(i).outPlayCard(j).getHardnessStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(tempPlayers.get(i).outPlayCard(j).getHardness().split("-")[1]));
                                    count++;
                                }
                                else if ((Double.parseDouble(tempPlayers.get(i).outPlayCard(j).getHardness()) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", "")))) {
                                    System.out.println("Player " + tempPlayers.get(i) + " plays " + tempPlayers.get(i).outPlayCard(j).getHardnessStr() + ": " + tempPlayers.get(i).outPlayCard(j).getHardness());
                                    tempPlayers.get(i).playCard(tempPlayers.get(i).outPlayCard(j));
                                    trumpValue.replace(tempPlayers.get(i).outPlayCard(j).getHardnessStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(tempPlayers.get(i).outPlayCard(j).getHardness()));
                                    count++;
                                }
                            }
                            if (count == 0 ){
                                passPlayers.add(tempPlayers.get(i));
                                System.out.println("Player " + tempPlayers.get(i) + " passes.");
                                tempPlayers.get(i).pickCard(deck.assign());
                            }
                        }

                    }
                    play();
                }
                    game();
                    starting = true;
                }

            }

    }
    public void play(){

        if (trumpValue.isEmpty()){ /*If the trumpValue is empty then the program runs the code which will(Unless the player chooses to pass) set the trumpcard*/
            int cardNumber;
            System.out.println("Choose a card to play");
            cardNumber = input.nextInt();
            while (cardNumber > players.get(playerID - 1).handCardNumber()){
                System.out.println("Error invalid input, please choose a valid card");
                cardNumber = input.nextInt();
            }
            playCard = players.get(playerID - 1).outPlayCard(cardNumber);
            players.get(playerID - 1).playCard(playCard);
            if (playCard.getTitle() != null) { //check if card is supertrump
                playSuperTrump(playCard);
                game();

            } else {
                System.out.println("Choose a category: 1.Hardness: " + playCard.getHardness() + "; 2.SpecificGravity: " + playCard.getSpecificGravity());
                int catagoryNumber;
                catagoryNumber = input.nextInt();
                if (catagoryNumber == 1) {
                    if (playCard.getHardness().contains("-")) {
                        System.out.println("Player " + playerID + " Sets Trump: " + playCard.getName() + " " + playCard.getHardnessStr() + ":" + playCard.getHardness().split("-")[1]);
                        trumpValue.put(playCard.getHardnessStr(), Double.parseDouble(playCard.getHardness().split("-")[1]));
                    } else {
                        System.out.println("Player " + playerID + " Sets Trump: " + playCard.getName() + " " + playCard.getHardnessStr() + ":" + playCard.getHardness());
                        trumpValue.put(playCard.getHardnessStr(), Double.parseDouble(playCard.getHardness()));
                    }

                } else if (catagoryNumber == 2) {
                    if (playCard.getSpecificGravity().contains("-")) {
                        System.out.println("Player " + playerID + " played "+ playCard.getName() + " " + playCard.getSpecificGravityStr() + ":" + playCard.getSpecificGravity().split("-")[1]);
                        trumpValue.put(playCard.getSpecificGravityStr(), Double.parseDouble(playCard.getSpecificGravity().split("-")[1]));
                    } else {
                        System.out.println("Player " + playerID + " played " + playCard.getName() + " " + playCard.getSpecificGravityStr() + ":" + playCard.getSpecificGravity());
                        trumpValue.put(playCard.getSpecificGravityStr(), Double.parseDouble(playCard.getSpecificGravity()));
                    }

                }
            }
        }else{
            //int cardNumber;
            System.out.println("Choose a card to play");
            cardNumber = input.nextInt();
            playCard = players.get(playerID - 1).outPlayCard(cardNumber);
            System.out.println("Choose a category: 1.Hardness: " + playCard.getHardness() + "; 2.SpecificGravity: " + playCard.getSpecificGravity());
            String oldTrumpCategory = trumpValue.keySet().toString().replace("[", "").replace("]", "");
            System.out.println(oldTrumpCategory+ " ");
            String newTrumpCategory = "";
            catagoryNumber = input.nextInt();
            if (catagoryNumber == 1){
                newTrumpCategory = "Hardness";
            }else if (cardNumber == 2){
                newTrumpCategory = "SpecificGravity";
            }
            while (!( newTrumpCategory == oldTrumpCategory )){ /*While the player selected category does not equal the category of the TrumpValue, error check*/
                System.out.println("Error, please choose the correct category");
                System.out.println("Choose a category: 1.Hardness: " + playCard.getHardness() + "; 2.SpecificGravity: " + playCard.getSpecificGravity());
                catagoryNumber = input.nextInt();

            }
            if (playCard.getTitle() != null) {
                playSuperTrump(playCard);
                game();

            } else if (playCard.getHardnessStr() == trumpValue.keySet().toString().replace("[", "").replace("]", "")) {
                if ((playCard.getHardness().contains("-") && (Double.parseDouble(playCard.getHardness().split("-")[1]) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", ""))))) { /*if the player selected card is greater than the trumpValue then the card is played.*/
                    System.out.println("Player " + (playerID - 1) + " plays " + playCard.getHardnessStr() + ": " + playCard.getHardness().split("-")[1]);
                    players.get(playerID - 1).playCard(playCard);
                    trumpValue.replace(playCard.getHardnessStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(playCard.getHardness().split("-")[1]));

                } else if ((Double.parseDouble(playCard.getHardness()) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", "")))) {
                    System.out.println("Player " + (playerID - 1) + " plays " + playCard.getHardnessStr() + ": " + playCard.getHardness());
                    players.get(playerID - 1).playCard(playCard);
                    trumpValue.replace(playCard.getHardnessStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(playCard.getHardness()));

                }
            } else if (playCard.getSpecificGravityStr() == trumpValue.keySet().toString().replace("[", "").replace("]", "")) {
                if ((playCard.getSpecificGravity().contains("-") && (Double.parseDouble(playCard.getSpecificGravity().split("-")[1]) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", ""))))) {
                    System.out.println("Player " + (playerID - 1) + " plays " + playCard.getSpecificGravityStr() + ": " + playCard.getSpecificGravity().split("-")[1]);
                    players.get(playerID - 1).playCard(playCard);
                    trumpValue.replace(playCard.getSpecificGravityStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(playCard.getSpecificGravity().split("-")[1]));

                } else if ((Double.parseDouble(playCard.getSpecificGravity()) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", "")))) {
                    System.out.println("Player " + (playerID - 1) + " plays " + playCard.getSpecificGravityStr() + ": " + playCard.getSpecificGravity());
                    players.get(playerID - 1).playCard(playCard);
                    trumpValue.replace(playCard.getSpecificGravityStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(playCard.getSpecificGravity()));

                } else { /*if the player selected card is not greater than the trumpValue then the message bellow is displayed.*/
                    System.out.println("Card category must be " + trumpValue.keySet().toString() + " higher than " + trumpValue.values().toString());
                    System.out.println("Choose a card to play");
                    cardNumber = input.nextInt();
                    players.get(playerID - 1).pickCard(deck.assign());
                }
            } else {
                passPlayers.add(players.get(playerID - 1));
                System.out.println("Player" + (playerID - 1) + " passes.");
            }

        }
        /* I didn't have time to properly implement this code */
        /*else if (catagoryNumber == 3) {
                if (trumpCard.getCleavage() == "none") {
                    trumpNumber = 1;
                }else if (trumpCard.getCleavage() == "poor/none") {
                    int trumpNumber = 2;
                }else if (trumpCard.getCleavage() == "1 poor") {
                    int trumpNumber = 3;
                } else if (trumpCard.getCleavage() == "2 poor") {
                    int trumpNumber = 4;
                }else if (trumpCard.getCleavage() == "1 good") {
                    int trumpNumber = 5;
                }else if (trumpCard.getCleavage() == "1 good, 1 poor"){
                    int trumpNumber = 6;
                } else if (trumpCard.getCleavage() == "2 good"){
                    int trumpNumber = 7;
                }else if (trumpCard.getCleavage() == "3 good"){
                    int trumpNumber = 8;
                } else if (trumpCard.getCleavage() == "1 perfect"){
                    int trumpNumber = 9;
                }else if (trumpCard.getCleavage() == "1 perfect, 1 good"){
                    int trumpNumber = 10;
                }else if (trumpCard.getCleavage() == "1 perfect, 2 good"){
                    int trumpNumber = 11;
                }else if (trumpCard.getCleavage() == "2 perfect, 1 good"){
                    int trumpNumber = 12;
                } else if (trumpCard.getCleavage() == "3 perfect"){
                    int trumpNumber = 13;
                }else if (trumpCard.getCleavage() == "4 perfect"){
                    int trumpNumber = 14;
                } else if (trumpCard.getCleavage() == "6 perfect"){
                    int trumpNumber = 15;
                }
                trumpValue.put(trumpCard.getCleavageStr(), Double.parseDouble(trumpNumber));
                System.out.println("Player " + playerID + " sets 'Trump' to " + trumpCard.getName() + " " + trumpCard.getCleavageStr() + ": " + trumpCard.getCleavage());
            }else if (catagoryNumber == 4){
                if (trumpCard.getCrustalAbundance() == "ultratrace") {
                    int trumpNumber = 1;
                }else if (trumpCard.getCrustalAbundance() == "trace") {
                    int trumpNumber = 2;
                }else if (trumpCard.getCrustalAbundance() == "low") {
                    int trumpNumber = 3;
                }else if (trumpCard.getCrustalAbundance() == "moderate") {
                    int trumpNumber = 4;
                }else if (trumpCard.getCrustalAbundance() == "high") {
                    int trumpNumber = 5;
                }else if (trumpCard.getCrustalAbundance() == "very high") {
                    int trumpNumber = 6;
                }
                trumpValue.put(trumpCard.getCrustalAbundanceStr(), Double.parseDouble(trumpNumber));
                System.out.println("Player " + playerID + " sets 'Trump' to " + trumpCard.getName() + " " + trumpCard.getCrustalAbundanceStr() + ": " + trumpCard.getCrustalAbundance());
            }else if (catagoryNumber == 5){
                if (trumpCard.getEconomicValue() == "trivial") {
                    int trumpNumber = 1;
                }else if (trumpCard.getEconomicValue() == "low") {
                    int trumpNumber = 2;
                }else if (trumpCard.getEconomicValue() == "moderate") {
                    int trumpNumber = 3;
                }else if (trumpCard.getEconomicValue() == "high") {
                    int trumpNumber = 4;
                }else if (trumpCard.getEconomicValue() == "very high") {
                    int trumpNumber = 5;
                }else if (trumpCard.getEconomicValue() == "I'm rich!") {
                    int trumpNumber = 6;
                }
                trumpValue.put(trumpCard.getEconomicValueStr(), Double.parseDouble(trumpNumber));
                System.out.println("Player " + playerID + " sets 'Trump' to " + trumpCard.getName() + " " + trumpCard.getEconomicValueStr() + ": " + trumpCard.getEconomicValue());

            }*/
    }

    public void playSuperTrump(Card trumpCard){ /* TrumpCard only has title and subtitle and no value for trump card, so it is set to 0.0*/
        trumpCount = 0;
        trumpValue.clear();
        if ((trumpCard.getTitle() ==("The Miner") )||(trumpCard.getTitle() == "The Petrologist") || (trumpCard.getTitle() == "The Gemmologist" )|| (trumpCard.getTitle() == "The Mineralogist")) {
            System.out.println("Changed Trump category to " + trumpCard.getSubtitle());
            trumpValue.put(trumpCard.getSubtitle(), 0.0);
            System.out.print(trumpCard.getSubtitle());
        } else if (trumpCard.getTitle() == "The Geologist") {
            System.out.println("Change Trump category to: 1.Hardness; 2.Specific gravity; 3. Cleavage; 4.Crustal Abundance; 5.Economic Value");
            int userChoice = input.nextInt();
            while (userChoice != 1 && userChoice != 2 && userChoice != 3 && userChoice != 4 && userChoice != 5){
                System.out.println("Error invalid input, please input '1','2','3','4', or '5'");
                System.out.println("Change Trump category: 1.Hardness; 2.Specific gravity; 3. Cleavage; 4.Crustal Abundance; 5.Economic Value");
            }
            if (userChoice == 1) {
                trumpValue.put("Hardness", 0.0);
            }
            else if (userChoice == 2) {
                trumpValue.put("SpecificGravity", 0.0);
            }
//            I didn't have time to implement the code that this code is related to (see above)
            else if (userChoice == 3) {
                trumpValue.put("Cleavage", 0.0);
            }
            else if (userChoice == 4) {
                trumpValue.put("CrustalAbundance", 0.0);
            }
            else if (userChoice == 5) {
                trumpValue.put("EconomicValue", 0.0);
            }

        } else if (trumpCard.getTitle() == "The Geophysicist") {
            System.out.println("1.Change trump category to Specific gravity; 2: throw magnetite");
            int userChoice = input.nextInt();
            while (userChoice != 1 && userChoice != 2 ) {
                System.out.println("Error invalid input, please input '1' or '2'");
                System.out.println("1.Change trump category to Specific gravity; 2: throw magnetite");
                userChoice = input.nextInt();
            }
            if (userChoice == 1) {
                trumpValue.put("SpecificGravity", 0.0);
            } else if (userChoice == 2) {
                    /*play magnetite card*/
            }
        }
    }
    public void game() {
        if (!trumpValue.isEmpty()) {
            String category = trumpValue.keySet().toString();
            System.out.println(category + " " + trumpValue.values().toString());
            for (Player tempPlayer : tempPlayers) {
                int count = 0;
                for (int i = 1; i <= tempPlayer.handCardNumber(); i++) { /*This is code for the non-user players*/
                    if (tempPlayer.outPlayCard(i).getHardnessStr() == category.replace("[", "").replace("]", "")) {
                        System.out.println(tempPlayer.outPlayCard(i).getHardnessStr() + " " + Double.parseDouble(tempPlayer.outPlayCard(i).getHardness() + category.replace("[", "").replace("]", "")));
                        if ((tempPlayer.outPlayCard(i).getHardness().contains("-") && (Double.parseDouble(tempPlayer.outPlayCard(i).getHardness().split("-")[1]) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", ""))))) {
                            System.out.println(tempPlayer.toString() + " plays " + tempPlayer.outPlayCard(i).getHardnessStr() + ": " + tempPlayer.outPlayCard(i).getHardness().split("-")[1]);
                            tempPlayer.playCard(tempPlayer.outPlayCard(i));
                            trumpValue.replace(tempPlayer.outPlayCard(i).getHardnessStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(tempPlayer.outPlayCard(i).getHardness().split("-")[1]));
                            count++;
                        } else if ((Double.parseDouble(tempPlayer.outPlayCard(i).getHardness()) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", "")))) {
                            System.out.println(tempPlayer.toString() + " plays " + tempPlayer.outPlayCard(i).getHardnessStr() + ": " + tempPlayer.outPlayCard(i).getHardness());
                            tempPlayer.playCard(tempPlayer.outPlayCard(i));
                            trumpValue.replace(tempPlayer.outPlayCard(i).getHardnessStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(tempPlayer.outPlayCard(i).getHardness()));
                            count++;
                        }
                    } else if (tempPlayer.outPlayCard(i).getSpecificGravityStr() == category.replace("[", "").replace("]", "").replace(" ", "")) {
                        if ((tempPlayer.outPlayCard(i).getSpecificGravity().contains("-") && (Double.parseDouble(tempPlayer.outPlayCard(i).getSpecificGravity().split("-")[1]) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", ""))))) {
                            System.out.println(tempPlayer.toString() + " plays " + tempPlayer.outPlayCard(i).getSpecificGravityStr() + ": " + tempPlayer.outPlayCard(i).getSpecificGravity().split("-")[1]);
                            tempPlayer.playCard(tempPlayer.outPlayCard(i));
                            trumpValue.replace(tempPlayer.outPlayCard(i).getSpecificGravityStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(tempPlayer.outPlayCard(i).getSpecificGravity().split("-")[1]));
                            count++;
                        } else if ((Double.parseDouble(tempPlayer.outPlayCard(i).getSpecificGravity()) > Double.parseDouble(trumpValue.values().toString().replace("[", "").replace("]", "")))) {
                            System.out.println(tempPlayer.toString() + " plays " + tempPlayer.outPlayCard(i).getSpecificGravityStr() + ": " + tempPlayer.outPlayCard(i).getSpecificGravity());
                            tempPlayer.playCard(tempPlayer.outPlayCard(i));
                            trumpValue.replace(tempPlayer.outPlayCard(i).getSpecificGravityStr(), Double.parseDouble(trumpValue.values().toString()), Double.parseDouble(tempPlayer.outPlayCard(i).getSpecificGravity()));
                            count++;
                        }
                    }

                }
                if (count == 0) {
                    passPlayers.add(tempPlayer);
                    System.out.println(tempPlayer.toString() + " passes.");
                    tempPlayer.pickCard(deck.assign());
                }

            }
            changeCategory();

            }


    }
    public void changeCategory(){
        if (passPlayers.size() == players.size()-1) {

            passPlayers.clear();

        }
    }
    public void pass(int playerID) {

        passPlayers.add(players.get(playerID));
        System.out.println("Player " + playerID + " passes.");

    }
    public boolean win(Player player){
        return player.win();

    }
}