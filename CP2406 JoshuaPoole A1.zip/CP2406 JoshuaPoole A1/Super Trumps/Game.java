import java.util.*;

/**
 * Created by Josh on 9/27/2016.
 */
public class Game {

    ArrayList<Player> players;
    ArrayList<Player> winners;
    ArrayList<Player> passPlayers;
    ArrayList<Player> tempPlayers;
    private Deck deck;
    private int option;
    private int playerID;
    private boolean start;
    private Card trumpCard;
    Map<String, Double> trumpValue;
    public Scanner input = new Scanner(System.in);
    public Random rand = new Random();

    public Game() {
        players = new ArrayList<Player>();
        passPlayers = new ArrayList<Player>();
        winners = new ArrayList<Player>();
        tempPlayers = new ArrayList<Player>();
        trumpValue = new HashMap<String, Double>();


        start();
        //game();
    }

    public void start() {
        int playerNumber;
        System.out.println("Enter the amount of players(must be between 3 and 5)");
        playerNumber = input.nextInt();
        while ((playerNumber != 3 && playerNumber != 4 && playerNumber != 5)) {
            System.out.println("Error invalid input");
            System.out.print("How many players?");
            playerNumber = input.nextInt();
        }
        System.out.println("Initializing players...");

        deck = new Deck();
        //System.out.println(deck.toString());
        //System.out.println(deck.getSize());
        deck.shuffle();
        //System.out.println(deck.getSize());
        //System.out.println(deck.toString());
        System.out.println("Shuffling and dealing cards...");

        for (int i = 1; i <= playerNumber; i++) {
            Player player = new Player(deck);
            players.add(player);
            tempPlayers.add(player);
        }
        System.out.println("Choose your player id;(1), (2), (3), (4), or (5):");
        playerID = input.nextInt();
        while (playerID > playerNumber && playerID != 1 && playerID != 2 && playerID != 3 && playerID != 4 && playerID != 5) {
            System.out.println("Error invalid input");
            System.out.println("Choose your player id:");
            playerID = input.nextInt();
        }
        System.out.println("Game options:(1) Look your cards; (2) Play cards; (3) Pass");
        option = input.nextInt();
        while (option != 1 && option != 2 && option != 3) {
            System.out.println("Error invalid input, please input '1' or '2'");
            System.out.print("Game options:(1) Look your cards; (2) Play cards");
            option = input.nextInt();
        }
        while (option == 1) {
            System.out.println(players.get(playerID - 1).toString() + ":" + players.get(playerID).showCardList(option));
            System.out.println("Game options:(1) Look your cards; (2) Play cards");
            option = input.nextInt();
        }
        if (option == 2) {
            int trumpCount = 0;
            while (trumpCount == 0) {

                int cardNumber;
                System.out.println("Choosing a card to play");
                cardNumber = input.nextInt();
                trumpCard = players.get(playerID - 1).outPlayCard(cardNumber);
                System.out.println("1.Hardness: " + trumpCard.getHardness() + "; 2.SpecificGravity: " + trumpCard.getSpecificGravity());
                int catagoryNumber;
                catagoryNumber = input.nextInt();
                if (trumpCard : TrumpCard){
                    if (trumpCard.getName() == "The Miner") {
                        trumpValue.put(trumpCard.getEconomicValueStr(), value);
                    } else if (trumpCard.getName() == "The Petrologist") {
                        trumpValue.put(trumpCard.getCrustalAbundanceStr(), value);
                    } else if (trumpCard.getName() == "The Gemmologist") {
                        trumpValue.put(trumpCard.getHardnessStr(), value);
                    } else if (trumpCard.getName() == "The Mineralogist") {
                        trumpValue.put(trumpCard.getCleavageStr(), value);
                    } else if (trumpCard.getName() == "The Geologist") {
                        System.out.println("Change Trump category: 1.Hardness; 2.Specific gravity; 3. Cleavage; 4.Crustal Abundance; 5.Economic Value");
                        int userChoice = input.nextInt();
                        while (userChoice != 1 && userChoice != 2 && userChoice != 3 && userChoice != 4 && userChoice != 5){
                            System.out.println("Error invalid input, please input '1','2','3','4', or '5'");
                            System.out.println("Change Trump category: 1.Hardness; 2.Specific gravity; 3. Cleavage; 4.Crustal Abundance; 5.Economic Value");
                        }
                        if (userChoice == 1) {
                            trumpValue.put(trumpCard.getHardnessStr(), value);
                        }
                        if (userChoice == 2) {
                            trumpValue.put(trumpCard.getSpecificGravityStr(), value);
                        }
                        if (userChoice == 3) {
                            trumpValue.put(trumpCard.getCleavageStr(), value);
                        }
                        if (userChoice == 4) {
                            trumpValue.put(trumpCard.getCrustalAbundanceStr(), value);
                        }
                        if (userChoice == 5) {
                            trumpValue.put(trumpCard.getEconomicValueStr(), value);
                        }


                    } else if (trumpCard.getName() == "The Geophysicist") {
                        System.out.println("1.Change trump category to Specific gravity; 2: throw magnetite");
                        int userChoice = input.nextInt();
                        while (userChoice != 1 && userChoice != 2 && userChoice != 3) {
                            System.out.println("Error invalid input, please input '1' or '2'");
                            System.out.println("1.Change trump category to Specific gravity; 2: throw magnetite");
                            userChoice = input.nextInt();
                            if (userChoice == 1) {
                                trumpValue.put(trumpCard.getSpecificGravityStr(), value);
                            } else if (userChoice == 2) {
                                //throw magnetite
                            }
                        }

                    }
                }


                if (catagoryNumber == 1) {
                    System.out.println("Player " + playerID + "played " + trumpCard.getHardnessStr() + trumpCard.getHardness());
                    trumpValue.put(trumpCard.getHardnessStr(), Double.parseDouble(trumpCard.getHardness()));
                } else if (catagoryNumber == 2) {
                    System.out.println("Player " + playerID + "played " + trumpCard.getSpecificGravityStr() + trumpCard.getSpecificGravity());
                    trumpValue.put(trumpCard.getSpecificGravityStr(), Double.parseDouble(trumpCard.getSpecificGravity()));
                }
                System.out.println("Player " + playerID + " sets 'Trump' " + trumpCard.getName() + ":" + trumpCard.getHardness());
            }
            trumpCount++;
            int cardNumber;
            System.out.println("Choosing a card to play");
            cardNumber = input.nextInt();
            trumpCard = players.get(playerID - 1).outPlayCard(cardNumber);
            System.out.println("1.Hardness: " + trumpCard.getHardness() + "; 2.SpecificGravity: " + trumpCard.getSpecificGravity());
            int catagoryNumber;
            catagoryNumber = input.nextInt();

            if (catagoryNumber == 1) {
                for (Player tempPlayer : tempPlayers) {
                    for (int i = 1; i <= 7; i++) {
                        if ((tempPlayer.outPlayCard(i).getHardnessStr() == "Hardness") && (Double.parseDouble(tempPlayer.outPlayCard(i).getHardness()) > Double.parseDouble(trumpCard.getHardness()))) {
                            System.out.println(tempPlayer.toString() + " plays " + tempPlayer.outPlayCard(i).getHardnessStr() + ": " + tempPlayer.outPlayCard(i).getHardness());
                        } else {
                            passPlayers.add(tempPlayer);
                        }
                    }
                }
                //System.out.println("Player " + playerID + "played " + trumpCard.getHardnessStr() + trumpCard.getHardness());
                //trumpValue.put(trumpCard.getHardnessStr(), Double.parseDouble(trumpCard.getHardness()));
            } else if (catagoryNumber == 2) {
                //System.out.println("Player " + playerID + "played " + trumpCard.getSpecificGravityStr() + trumpCard.getSpecificGravity());
                //trumpValue.put(trumpCard.getSpecificGravityStr(), Double.parseDouble(trumpCard.getSpecificGravity()));
            }
            //System.out.println("Player " + playerID + " sets 'Trump' " + trumpCard.getName() + ":" + trumpCard.getHardness());

        } else if (option == 3) {
            pass(playerID);

        }


    }

    public void game() {
        System.out.println("Waiting for other players to play...");
        tempPlayers.remove(playerID - 1);
        for (Player p : passPlayers) {
            if (passPlayers.size() == (players.size() - 1)) {
                passPlayers.remove(p);
            }
        }
        for (Player tempPlayer : tempPlayers) {
            for (int i = 1; i <= 8; i++) {
                if ((tempPlayer.outPlayCard(i).getName() == trumpCard.getName()) && (Double.parseDouble(tempPlayer.outPlayCard(i).getHardness()) > Double.parseDouble(trumpCard.getHardness()))) {
                    System.out.println(tempPlayer.toString() + " plays " + tempPlayer.outPlayCard(i).getName() + ": " + tempPlayer.outPlayCard(i).getHardness());
                } else {
                    passPlayers.add(tempPlayer);
                }
            }
        }

    }

    public void pass(int playerID) {
        passPlayers.add(players.get(playerID));
    }
            /*

            //if passPlayers does not contain the current player
            if (!passPlayers.contains(players.get(playerID-1))){
                System.out.print("(1)Look for your cards, (2)Play cards, (3)Pass");
                String userInput = input.nextLine();
                if (userInput.equalsIgnoreCase("C")){
                    boolean running = false;
                    while (!(running)) {
                        for (Player o : players) {
                            System.out.print(o.playcards.name + " ");
                            System.out.print("Type a card's name to examine it, (C)lear selections, (B)ack");
                            String userInput2 = input.nextLine();
                            if (userInput2 is a cards name){
                                if (card is a trumpcard){
                                    //supertrump options;
                                    running = true;}
                                        else if (card is a playcard){
                                    System.out.print(o.playcards.name, o.playcards.chemistry, o.playcards.classification, o.playcards.crystalSystem, o.playcards.occurrenceString, o.playcards.hardness, o.playcards.specificGravity, o.playcards.cleavage, o.playcards.crustalAbundance, o.playcards.economicValue);
                                    System.out.print("Type a card's atrribute to select it, (C)lear selections, (B)ack");
                                    String userInput3 = input.nextLine();
                                    if (userInput3 is an attribute of o.playcards){
                                        Dictionary<String, String> userSelection;
                                        boolean isPass = false;
                                        isPass.cardChecker(userSelection);

                                        running = true;}
                                            else if (userInput3.equalsIgnoreCase("C")) {
                                        selectedCards.clear();
                                        System.out.print("Type a card's atrribute to select it, (C)lear selections, (B)ack");}
                                    else if (userInput3.equalsIgnoreCase("B")) {
                                        System.out.print("Type a card's name to examine it, (C)lear selections, (B)ack");}
                                    else{
                                        System.out.print("Invalid input");
                                        System.out.print("Type a card's atrribute to select it, (C)lear selections, (B)ack");}

                                }

                            }

                        }


                    }
                }
                ;

                    else
                    if (isPass = true){
                        remove card from player and return card to deck;
                        passPlayers.add(i);
                        trumpPass.put(trumpValue[0], trumpValue[1]);
                    }
                    else
                        trumpValue.put(selectedCards[0], selectedCards[1]);
                    System.out.print(i + " played " selectedCards[0] + ": " + selectedCards[1]);
                    remove card from player and return card to deck;

                }
                //Pass selected
                else if (userInput.equalsIgnoreCase("Pa")){
                    remove card from player and return card to deck;
                    passPlayers.add(i);
                    trumpPass.put(trumpValue[0], trumpValue[1]);
                }
            }
        }

/*
            while (players.size() > 1) {
            //turns
            for (Player i : players) {
                //check if won
                if (i.playcards.size() == 0) {
                    winners.add(i);
                    players.remove(i);
                }

                //round logic
                Dictionary<String, String> trumpValue;
                Dictionary<String, String> trumpPass;



                //check if player is a pass player
                if (passPlayers.size() == players.size()-1) {
                    passPlayers.clear();
                } else if (trumpPass != trumpValue) {
                    passPlayers.clear();
                }

            }
        }
    }
        void deal(){
            for (int i=0; i < deck.getSize(); i++){
                deck.getCard(i);
            }
            for (int j=0; j < 8 ; j++){
                playcards.add(deck.getCard(j));

            }}

        void game(){
                for (Player i : players){
                    Dictionary<String, String> selectedCards;
                    //if passPlayers does not contain the current player
                    if (!passPlayers.contains(i)){
                        System.out.print("(C)ards, (P)lay card, (Pa)ss");
                        String userInput = input.nextLine();
                        if (userInput.equalsIgnoreCase("C")){
                            boolean running = false;
                            while (!(running)) {
                                for (Player o : players) {
                                    System.out.print(o.playcards.name + " ");
                                    System.out.print("Type a card's name to examine it, (C)lear selections, (B)ack");
                                    String userInput2 = input.nextLine();
                                    if (userInput2 is a cards name){
                                        if (card is a trumpcard){
                                            //supertrump options;
                                            running = true;}
                                        else if (card is a playcard){
                                            System.out.print(o.playcards.name, o.playcards.chemistry, o.playcards.classification, o.playcards.crystalSystem, o.playcards.occurrenceString, o.playcards.hardness, o.playcards.specificGravity, o.playcards.cleavage, o.playcards.crustalAbundance, o.playcards.economicValue);
                                            System.out.print("Type a card's atrribute to select it, (C)lear selections, (B)ack");
                                            String userInput3 = input.nextLine();
                                            if (userInput3 is an attribute of o.playcards){
                                                Dictionary<String, String> userSelection;
                                                boolean isPass = false;
                                                isPass.cardChecker(userSelection);

                                                running = true;}
                                            else if (userInput3.equalsIgnoreCase("C")) {
                                                selectedCards.clear();
                                                System.out.print("Type a card's atrribute to select it, (C)lear selections, (B)ack");}
                                            else if (userInput3.equalsIgnoreCase("B")) {
                                                System.out.print("Type a card's name to examine it, (C)lear selections, (B)ack");}
                                            else{
                                                System.out.print("Invalid input");
                                                System.out.print("Type a card's atrribute to select it, (C)lear selections, (B)ack");}

                                            }

                                        }

                                    }


                                }
                            }
                        //Play card selected
                        else if (userInput.equalsIgnoreCase("P")){
                            if (selectedCards = Geophysicist AND Magnetite{
                                remove all cards from player hand and return them to the deck;
                                System.out.print(i + " played the Geophysicist and magnetite card; they are the winner!");}
                            else if (selectedCards > 1)
                                System.out.print("Error only one card can be selected unless the cards are the Geophysicist and magnetite");

                            else
                                if (isPass = true){
                                    remove card from player and return card to deck;
                                    passPlayers.add(i);
                                    trumpPass.put(trumpValue[0], trumpValue[1]);
                                }
                                else
                                    trumpValue.put(selectedCards[0], selectedCards[1]);
                                    System.out.print(i + " played " selectedCards[0] + ": " + selectedCards[1]);
                                    remove card from player and return card to deck;

                        }
                        //Pass selected
                        else if (userInput.equalsIgnoreCase("Pa")){
                            remove card from player and return card to deck;
                            passPlayers.add(i);
                            trumpPass.put(trumpValue[0], trumpValue[1]);
                    }
                    }
                }
        static cardChecker(userSelection){
            if (trumpValue.size() > 0){
                if (userSelection[0] = trumpValue[0]){
                    if (userSelection[1] => trumpValue[1]){
                    return userSelection;}}
                else if (userSelections value < trumpValue value){
                    return true;}
            else
                return userselection;}

        }}}



        //print ("Game over.");
        //clear all data;
        //call Menu;
*/



    //}
}