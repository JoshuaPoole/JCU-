import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Josh on 10/24/2016.
 */
public class Form1 {
    private JPanel MenuPanel;
     JButton playButton;
     JButton instructionsButton;
     JButton quitButton;
    private JPanel titlePanel;
    private JPanel buttonPanel;
    private JLabel Title;
    private JFrame frame1;
    private Object nextForm;

    public void setVisible(boolean visible){
        frame1.setVisible(visible);
    }


    public Form1() {
        frame1 = new JFrame("Mineral SuperTrumps");
        frame1.setContentPane(this.MenuPanel);
        frame1.setSize(700, 600);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
