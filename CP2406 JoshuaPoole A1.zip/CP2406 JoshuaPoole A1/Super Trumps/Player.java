import java.util.ArrayList;

/**
 * Created by jc313836 on 13/09/16.
 */
public class Player  {
    private Hand hand;
    private String playerID;
    private final int id;
    private Deck deck;
    private static int count = 0;


    public Player(){
        count ++;
        id = count;
        playerID = "Player" + id;
        hand = new Hand();
        deck = new Deck();
    }
    public Player(Deck in_deck){
        count ++;
        id = count;
        playerID = "Player" + id;
        hand = new Hand();
        deck = in_deck;
        assignCards(9);
    }
    public void assign(Deck in_deck){
        if (!in_deck.isEmpty()){
            Card currentCard = deck.dealCard();
            hand.add(currentCard);
        }
    }
    public void assign(){
        assign(deck);
    }
    public void assignCards(Deck in_deck, int number) {
        for (int i = 0; i < number; i++) {
            assign(deck);
        }
    }
    public void assignCards(int number){
        for (int i =0; i<number; i++){
            assign(deck);
        }
    }
    public void pickCard(Card in_card){
        hand.add(in_card);
    }
    public void playCard(Card out_card){
        hand.remove(out_card);
    }
    public int handCardNumber(){
        return hand.size();
    }
    public boolean win(){
        return (hand.size() == 0) ;
    }
    public String toString(){
        return playerID;
    }
    public Card getPlayCard(int number){
        return hand.getPlayCard(number - 1);
    }
    public Card outPlayCard(int number){
        return hand.removeUsedCard(number - 1);
    }
    public String showCardList(int option){// option: 1, look; 2, play
        String cardList = "\n Your CardList \n";
        if (option == 1){
            ArrayList<Card> playcards = hand.getPlaycards();
            for (int i = 1; i< playcards.size(); i++){
                cardList += i + ", " + playcards.get(i-1) + "\n";
            }

        }
        return cardList;
    }
}

