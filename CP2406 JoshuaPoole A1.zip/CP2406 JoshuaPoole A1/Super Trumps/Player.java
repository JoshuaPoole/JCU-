import java.util.ArrayList;

/**
 * Created by jc313836 on 13/09/16.
 */
public class Player  {
    Deck deck;
    ArrayList<Card> playcards;

    Player(){

    }

    void cardDealer(){
        for (int i=0; i < deck.getSize(); i++){
            deck.getCard(i);
        }
        for (int j=0; j < 8 ; j++){
            playcards.add(deck.getCard(j));

        }

    }
}

