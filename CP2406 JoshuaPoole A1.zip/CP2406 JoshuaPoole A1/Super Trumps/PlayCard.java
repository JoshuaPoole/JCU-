public class PlayCard extends Card{
    String chemistry;
    String classification;
    String crystalSystem;
    String occurrenceString;
    String hardness;
    String specificGravity;
    String cleavage;
    String crustalAbundance;
    String economicValue;
    String hardnessStr;
    String specificGravityStr;
    String cleavageStr;
    String crustalAbundanceStr;
    String economicValueStr;

    PlayCard(String in_name, String in_chemistry, String in_classification, String in_crystalSystem, String in_occurrence, String in_hardnessStr, String in_hardness, String in_specificGravityStr, String in_specificGravity,  String in_cleavageStr, String in_cleavage, String crustalAbundanceStr, String in_crustalAbundance, String economicValueStr, String in_economicValue){
        name = in_name;
        chemistry = in_chemistry;
        classification = in_classification;
        crystalSystem = in_crystalSystem;
        occurrenceString = in_occurrence;
        hardness = in_hardness;
        specificGravity = in_specificGravity;
        cleavage = in_cleavage;
        crustalAbundance = in_crustalAbundance;
        economicValue = in_economicValue;
        hardnessStr = in_hardnessStr;
        specificGravityStr = in_specificGravityStr;
        cleavageStr = in_cleavageStr;
        crustalAbundanceStr = crustalAbundanceStr;
        economicValueStr = economicValueStr;
    }
    public String toString(){
        String cardString = "<" + name + "," + chemistry + "," + classification + ","
                + crystalSystem + "," + occurrenceString + "," + hardness + ","
                + specificGravity + "," + cleavage + "," + crustalAbundance + "," + economicValue
                + ">";
        return cardString;
    }
    public String getName(){
        return name;
    }
    public String getChemistry(){
        return chemistry;
    }
    public String getClassification(){
        return classification;
    }
    public String getCrystalSystem(){
        return crystalSystem;
    }
    public String getOccurrenceString(){
        return occurrenceString;
    }
    public String getHardness(){
        return hardness;
    }
    public String getSpecificGravity(){
        return specificGravity;
    }
    public String getCleavage(){
        return cleavage;
    }
    public String getCrustalAbundance(){
        return crustalAbundance;
    }
    public String getEconomicValue(){
        return economicValue;
    }

    public String getCleavageStr() {
        return cleavageStr;
    }

    public String getCrustalAbundanceStr() {
        return crustalAbundanceStr;
    }

    public String getSpecificGravityStr() {
        return specificGravityStr;
    }

    public String getEconomicValueStr() {
        return economicValueStr;
    }

    public String getHardnessStr() {
        return hardnessStr;
    }
}

