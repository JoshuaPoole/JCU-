public class PlayCard extends Card{
    String chemistry;
    String classification;
    String crystalSystem;
    String occurrenceString;
    String hardness;
    String specificGravity;
    String cleavage;
    String crustalAbundance;
    String economicValue;

    PlayCard(String in_name, String in_chemistry, String in_classification, String in_crystalSystem, String in_occurrence, String in_hardness, String in_specificGravity, String in_cleavage, String in_crustalAbundance, String in_economicValue){
        name = in_name;
        chemistry = in_chemistry;
        classification = in_classification;
        crystalSystem = in_crystalSystem;
        occurrenceString = in_occurrence;
        hardness = in_hardness;
        specificGravity = in_specificGravity;
        cleavage = in_cleavage;
        crustalAbundance = in_crustalAbundance;
        economicValue = in_economicValue;
    }
}

