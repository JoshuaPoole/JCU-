import javax.swing.*;

/**
 * Created by Josh on 10/24/2016.
 */
public class Form3 {
    private JButton playCards;
    private JButton pass;
    private JPanel gameOptions;
    private JPanel gameStatus;
    private JPanel GamePanel;
    private JFrame frame3;

    public void setVisible(boolean visible){
        frame3.setVisible(visible);
    }

    public Form3(){
        frame3 = new JFrame("Mineral SuperTrumps");
        frame3.setContentPane(this.GamePanel);
        frame3.setSize(800, 700);
        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
