import java.util.ArrayList;

/**
 * Created by Sisi on 6/10/2016.
 */
public class Hand {
    ArrayList<Card> playcards;

    public Hand(){
        playcards = new ArrayList<Card>();
    }
    public Hand(int n){
        playcards = new ArrayList<Card>();
        for (int i = 0; i < n; i++){
            Card currentCard = new Card();
            playcards.add(currentCard);
        }
    }
    public void add(Card card){
        playcards.add(card);
    }
    public void remove(Card card){
        playcards.remove(card);
    }
    public int size(){
        return playcards.size();
    }
    public int numberToPick(boolean pass){
        int number = 0;
        if (pass != true){
            return 0;
        }else{
            if (playcards != null)
                number = 1;
            return number;
        }
    }
    public ArrayList<Card> getPlaycards(){
        return playcards;
    }
    public Card getPlayCard(int i){
        return playcards.get(i);
    }
    public Card removeUsedCard(int i){
        return playcards.remove(i);
    }
    public String toString(){
        String playcardsString = " ";
        for (Card card: playcards){
            playcardsString += card + "\n ";
        }
        return playcardsString;
    }

}
